﻿Imports System.IO

Public Class clsConnection
    Private mConnection As New SqlClient.SqlConnection
    Private mConnectionString As String
    Private mIniFile As String = "AppConfig.INI"

    Private SQLServerName As String = "(ISALE)"
    Private SQLDatabase As String = "QuanLyHangHoa"
    Private UserID As String = "sa"
    Private mPassword As String = "123"

    Public ReadOnly Property ConnString() As String
        Get
            Return mConnectionString
        End Get

    End Property

    Public Property IniFile() As String
        Get
            Return mIniFile
        End Get
        Set(ByVal value As String)
            mIniFile = value
        End Set
    End Property
    Public Property ServerName() As String
        Get
            Return SQLServerName
        End Get
        Set(ByVal value As String)
            SQLServerName = value
        End Set
    End Property
    Public Property DatabaseName() As String
        Get
            Return SQLDatabase
        End Get
        Set(ByVal value As String)
            SQLDatabase = value
        End Set
    End Property
    Public Property UserName() As String
        Get
            Return UserID
        End Get
        Set(ByVal value As String)
            UserID = value
        End Set
    End Property

    Public Property Password() As String
        Get
            Return mPassword
        End Get
        Set(ByVal value As String)
            mPassword = value
        End Set
    End Property
    Public Function GetConnectionStringWithIniFile() As String
        Dim str As String = ""
        Try
            Dim mReader As New StreamReader(mIniFile)
            Dim line As String = ""

            While mReader.Peek > -1
                line = mReader.ReadLine
                Select Case (line.Substring(0, line.IndexOf("=")))
                    Case "SQLServerName"
                        SQLServerName = GetValue(line)
                    Case "SQLDatabase"
                        SQLDatabase = GetValue(line)
                    Case "UserID"
                        UserID = GetValue(line)

                End Select
            End While
            str = GetConnectionString()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Return str
    End Function

    Public Function GetValue(ByVal line As String) As String
        Dim stringValue As String = ""
        If line <> "" Then
            stringValue = line.Substring(line.LastIndexOf("=") + 1)
        End If
        Return stringValue
    End Function

    Public Function GetConnectionString() As String
        Dim conString As String = ""
        conString = "Data Source="
        If SQLServerName <> "" Then
            conString += SQLServerName
            conString += ";database=" + SQLDatabase + ";uid=" + UserID + ";pwd=" + mPassword
        End If


        Return conString
    End Function
    Public Function Connec() As Boolean
        Dim IsExist As Boolean = False
        Try
            If mConnection.State = Data.ConnectionState.Closed Then
                If mConnection.ConnectionString = "" Then
                    mConnectionString = GetConnectionStringWithIniFile()
                    mConnection.ConnectionString = mConnectionString
                End If
                mConnection.Open()
                IsExist = True
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Return IsExist
    End Function

End Class
