﻿Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel

Public Class MainForm
    Private Declare Auto Function GetPrivateProfileString Lib "kernel32" (ByVal lpAppName As String, _
       ByVal lpKeyName As String, _
       ByVal lpDefault As String, _
       ByVal lpReturnedString As StringBuilder, _
       ByVal nSize As Integer, _
       ByVal lpFileName As String) As Integer

    Sub ReadIniFile()

        Dim res As Integer
        Dim server As StringBuilder
        Dim database As StringBuilder
        Dim user As StringBuilder
        Dim pass As StringBuilder

        server = New StringBuilder(500)
        database = New StringBuilder(500)
        user = New StringBuilder(500)
        pass = New StringBuilder(500)

        res = GetPrivateProfileString("SystemConfig", "SQLServer", "", server, server.Capacity, My.Application.Info.DirectoryPath & "\AppConfig.INI")
        'res = GetPrivateProfileString("SystemConfig", "SQLDatabase", "", database, database.Capacity, My.Application.Info.DirectoryPath & "\AppConfig.INI")
        'res = GetPrivateProfileString("SystemConfig", "User", "", user, user.Capacity, My.Application.Info.DirectoryPath & "\AppConfig.INI")
        'res = GetPrivateProfileString("SystemConfig", "Password", "", pass, pass.Capacity, My.Application.Info.DirectoryPath & "\AppConfig.INI")
        TextEdit1.Text = server.ToString()

    End Sub

    

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ReadIniFile()
       

    End Sub
End Class



