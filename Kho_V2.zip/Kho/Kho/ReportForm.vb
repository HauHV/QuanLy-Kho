﻿Public Class ReportForm


    

    Private Sub SimpleButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SimpleButton1.Click

        'Dim datLastDay As Date = DateSerial(2017, 3, 1)
        Dim datLastDay As Date = DateSerial(2017, 3 + 1, 0)
        TextEdit1.Text = datLastDay


    End Sub
End Class