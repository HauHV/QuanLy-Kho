﻿Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel

Public Class GiaVonForm

    Private Sub TruyVanFunction()
        Dim db As New DataClasses1DataContext(ConnectionString)
        'GridControl1.DataSource = db.HangHoas.ToList()

        'Dim Hang = (From p In db.viewReports Select p).ToList
        'Dim Hang = db.sp_QLyKho(DateSerial(2017, 2, 1), DateSerial(2017, 2, 28)).ToList
        Dim fromDate, toDate As New DateTime
        fromDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue), 1)
        toDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue) + 1, 0)

        Dim Hang = db.sp_DonGiaVon(fromDate, toDate).ToList
        GridControl1.DataSource = Hang
        'Dim Hang = db.sp_QLyKho3(fromDate, toDate, MaKho).ToList
        'GridControl1.DataSource = Hang
        'Dim Hang = db.HangHoas.Where(Function(p) p.Equals("h1")).ToList
        'GridControl1.DataSource = Hang
    End Sub

    Private Sub btnGiaVon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGiaVon.Click
        If txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
        Else
            TruyVanFunction()
        End If
    End Sub

    Private Sub GiaVonForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ReadIniFile()
        ConnectDB()
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private _DoiSo As String

    Public Sub New(ByVal pDoiSo As String)
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        _DoiSo = pDoiSo
    End Sub

End Class