Public Class XtraReport1

End Class