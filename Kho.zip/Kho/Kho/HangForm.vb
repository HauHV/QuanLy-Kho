﻿Imports System.IO
Imports System.Data.SqlClient


Public Class HangForm
    Dim SQLDatabase As String
    'Dim Domain As String
    Dim SQLServer As String
    Dim User As String
    Dim Password As String


    Friend Sub SearchConfigFile()
        Dim Found As Boolean = False
        Dim RelativePath As String
        Dim FullPath As String


        RelativePath = System.IO.Directory.GetCurrentDirectory()
        FullPath = RelativePath + "\AppConfig.INI"

        Dim objReader As New StreamReader(FullPath)
        Dim sLine As String = ""
        Dim arrText As New ArrayList()

        Do
            sLine = objReader.ReadLine()
            If Not sLine Is Nothing Then
                arrText.Add(sLine)
            End If
        Loop Until sLine Is Nothing
        objReader.Close()



        SQLServer = arrText(2)
        SQLDatabase = arrText(3)
        User = arrText(4)
        Password = arrText(5)

    End Sub


    Friend Sub ConnectToDatabase()

        Dim myConnection As SqlConnection
        myConnection = New SqlConnection

        myConnection = New SqlConnection("data source=" & SQLServer & ";" & _
        "initial catalog=" & SQLDatabase & ";" & _
        "User Id=" & User & "; password=" & Password & ";")

    End Sub



    Private Sub HangForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DateEdit1.EditValue = Now.Date
        'DateEdit2.EditValue = Now.Date
        FillMaKho()
    End Sub

    Private Sub FillMaKho()
        Dim db As New DataClasses1DataContext
        Dim Kho = db.viewKho2s.ToList()
        cboLocation.Properties.DataSource = Kho
        Dim mHeight As Integer = If(Kho.Count > 10, 10, Kho.Count) * 19 + 22
        cboLocation.Properties.PopupFormSize = New Size(cboLocation.Width, mHeight)
        cboLocation.Properties.PopupFormMinSize = New Size(cboLocation.Width, mHeight)
    End Sub

    Private Sub TruyVanFunction()
        Dim db As New DataClasses1DataContext
        'GridControl1.DataSource = db.HangHoas.ToList()

        'Dim Hang = (From p In db.viewReports Select p).ToList
        'Dim Hang = db.sp_QLyKho(DateSerial(2017, 2, 1), DateSerial(2017, 2, 28)).ToList
        Dim fromDate, toDate As New DateTime
        Dim MaKho As String
        fromDate = txtFrom.EditValue
        toDate = txtTo.EditValue
        MaKho = cboLocation.EditValue

        Dim Hang = db.sp_QLyVon4(fromDate, toDate, MaKho).ToList
        GridControl1.DataSource = Hang
        'Dim Hang = db.sp_QLyKho3(fromDate, toDate, MaKho).ToList
        'GridControl1.DataSource = Hang
        'Dim Hang = db.HangHoas.Where(Function(p) p.Equals("h1")).ToList
        'GridControl1.DataSource = Hang
    End Sub

    Private Sub btnXem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXem.Click

        If txtFrom.EditValue = Nothing Or txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtTo, "Dữ liệu không được trống")
            'DxErrorProvider1.SetError(cboLocation, "Dữ liệu không được trống")
        Else
            If txtFrom.EditValue > txtTo.EditValue Then
                txtFrom.EditValue = txtTo.EditValue
                TruyVanFunction()

            Else
                TruyVanFunction()
            End If

        End If

    End Sub

    Private Sub SimpleButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SimpleButton2.Click
        Me.Close()

    End Sub

    Private Sub SimpleButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SimpleButton1.Click
        GridControl1.DataSource = Nothing
        cboLocation.EditValue = Nothing

    End Sub

    Private Sub DateEdit1_EditValueChanging(ByVal sender As Object, ByVal e As DevExpress.XtraEditors.Controls.ChangingEventArgs)
        DxErrorProvider1.SetError(txtFrom, "")
    End Sub

    Private Sub DateEdit2_EditValueChanging(ByVal sender As Object, ByVal e As DevExpress.XtraEditors.Controls.ChangingEventArgs)
        DxErrorProvider1.SetError(txtTo, "")
    End Sub



   
    Private Sub btnReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReport.Click
        'Dim dt As New DataTable
        ''
        'With dt
        '    .Columns.Add("TenHang")
        '    .Columns.Add("MaKho")

        'End With
        ''
        'For Each dr As DataGridViewRow In Me.GridView1.
        '    dt.Rows.Add(dr.Cells("TenHang").Value, dr.Cells("MaKho").Value)
        'Next
        ''
        Dim rptDoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        rptDoc = New CrystalReport1
        rptDoc.SetDataSource(GridControl1.DataSource)
        '
        MainForm.CrystalReportViewer1.ReportSource = rptDoc
        MainForm.ShowDialog()
        MainForm.Dispose()
    End Sub
End Class


